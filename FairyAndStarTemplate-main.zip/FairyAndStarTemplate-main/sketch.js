function preload()
{
   //preload the images here
}

function setup() {
	createCanvas(800, 750);
}


function draw() {
  background("black");

}
